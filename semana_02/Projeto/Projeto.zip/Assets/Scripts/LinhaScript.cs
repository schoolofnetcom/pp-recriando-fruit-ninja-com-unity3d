﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LinhaScript : MonoBehaviour {

	int numeroDeVertices = 0;
	LineRenderer linha;
	bool apertandoBotaoDoMouse = false;
	public GameObject boom;

	// Use this for initialization
	void Start () {
		linha = GetComponent<LineRenderer> ();
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetMouseButtonDown (0)) {
			apertandoBotaoDoMouse = true;
		}

		if (Input.GetMouseButtonUp (0)) {
			apertandoBotaoDoMouse = false;
		}

		if (apertandoBotaoDoMouse) {
			CriarLinha ();
		} else {
			DeletarLinha ();
		}
	}

	void CriarLinha(){
		linha.SetVertexCount (numeroDeVertices + 1);
		Vector3 posicaoDoMouse = Camera.main.ScreenToWorldPoint(Input.mousePosition);
		linha.SetPosition (numeroDeVertices, posicaoDoMouse);
		numeroDeVertices++;
		BoxCollider2D colisorLinha = gameObject.AddComponent<BoxCollider2D> ();
		colisorLinha.transform.position = linha.transform.localPosition;
		colisorLinha.size = new Vector2 (0.1f, 0.1f);
	}

	void DeletarLinha(){
		numeroDeVertices = 0;
		linha.SetVertexCount (0);
		BoxCollider2D[] colisoresDaLinha = GetComponents<BoxCollider2D> ();

		foreach (BoxCollider2D colisor in colisoresDaLinha) {
			Destroy (colisor);
		}

	}

	void OnCollisionEnter2D(Collision2D obj){
		if(obj.gameObject.tag == "Bomba"){
			GameObject boomClone = Instantiate (boom, obj.transform.position, Quaternion.identity) as GameObject;
			Destroy (boomClone, 5f);
			Destroy (obj.gameObject);
		}
	}
}
